
import { Button } from 'react-bootstrap';
import { Container } from 'react-bootstrap';
import Form from 'react-bootstrap/Form';
import axios from 'axios';
import { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';

export default function Login() {

    const [UserName, setUserName] = useState('');
    const [Password, setPassword] = useState('');
    const navigate = useNavigate();
    async function handleSubmit(e) {
        e.preventDefault();

        let userDTO = {
            UserName: UserName,
            Password: Password,
        }

        await axios.post('https://localhost:7217/api/User/Login',
            userDTO
        )
            .then(async (response) => {
                if (response.data == true) {
                    await localStorage.setItem("isLogin", true);
                    alert("Login Successful");
                    checkLogged() ? navigate("/formList") : checkLogged()
                }
                else {
                    alert("Wrong Password");
                }
            })
            .catch((error) => {
                console.log(error);
            })
    }

    function checkLogged() {
        const isLogin = localStorage.getItem("isLogin");
        var result = false
        return isLogin !== null ? result = true : result
    }
    return (
        <Container>
            <Form size="sm">
                <Form.Group controlId="exampleForm.ControlInput1">
                    <Form.Label>User Name</Form.Label>
                    <Form.Control
                        type="text"
                        name="UserName"
                        onChange={(event) =>
                            setUserName(event.target.value)
                        }
                        value={UserName} />
                </Form.Group>

                <Form.Group controlId="exampleForm.ControlInput1">
                    <Form.Label>Password</Form.Label>
                    <Form.Control
                        type="text"
                        name="Password"
                        onChange={(event) =>
                            setPassword(event.target.value)
                        }
                        value={Password}
                    />
                </Form.Group>
                <Button type="button" className="create-button btn btn-primary" onClick={handleSubmit}>Kaydet</Button>
            </Form>

        </Container>
    );
}