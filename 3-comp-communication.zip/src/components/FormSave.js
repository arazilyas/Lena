import { Container } from 'react-bootstrap';
import Form from 'react-bootstrap/Form';
import axios from 'axios';
import { Button } from 'react-bootstrap';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';


export default function FormSave() {

  const [Name, setName] = useState('');
  const [Surname, setSurname] = useState('');
  const [Description, setDescription] = useState('');
  const [Age, setAge] = useState('');

  const navigate = useNavigate();

  function handleSubmit(e) {
    e.preventDefault();
    let formDTO = {
      Name: Name,
      Surname: Surname,
      Age: Age,
      Description: Description
    }

    axios.post('https://localhost:7217/api/UserForm/SaveForm',
      formDTO
    )
      .then((response) => {
        if (response.data == true) {
          alert("Success")
          navigate("/formList")

        }
      })
      .catch((error) => {
        console.log(error);
      })
  }
  return (
    <Container>
      <Form size="sm">
        <Form.Group controlId="exampleForm.ControlInput1">
          <Form.Label>Name</Form.Label>
          <Form.Control
            type="text"
            name="Name"
            onChange={(event) =>
              setName(event.target.value)
            }
            value={Name} />
        </Form.Group>

        <Form.Group controlId="exampleForm.ControlInput1">
          <Form.Label>Surname</Form.Label>
          <Form.Control
            type="text"
            name="Surname"
            onChange={(event) =>
              setSurname(event.target.value)
            }
            value={Surname}
          />
        </Form.Group>

        <Form.Group controlId="exampleForm.ControlInput1">
          <Form.Label>Age</Form.Label>
          <Form.Control
            type="number"
            onChange={(event) =>
              setAge(event.target.value)
            }
            value={Age}
          />
        </Form.Group>

        <Form.Group controlId="exampleForm.ControlInput1">
          <Form.Label>Description</Form.Label>
          <Form.Control
            type="textarea"
            onChange={(event) =>
              setDescription(event.target.value)
            }
            value={Description} />
        </Form.Group>

        <Button type="button" className="create-button btn btn-primary" onClick={handleSubmit}>Kaydet</Button>

      </Form>

    </Container>
  );
}