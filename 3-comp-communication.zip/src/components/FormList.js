import DataTable from 'react-data-table-component';
import { Link } from "react-router-dom";
import axios from 'axios';
import { Button } from 'react-bootstrap';
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';

import 'bootstrap/dist/css/bootstrap.min.css';

export default function FormList() {
  const [state, setState] = useState([]);
  const navigate = useNavigate();
  function handleSubmit(id) {
    navigate("/formList/" + id)
  }

  useEffect(() => {
    axios.get("https://localhost:7217/api/UserForm/GetFormList")
      .then(res => setState(res.data))
      .catch(err => console.log(err));
  }, []);


  const columns = [
    {
      name: 'Id',
      selector: row => row.id,
    },
    {
      name: 'Name',
      selector: row => row.name,
    },
    {
      name: 'Surname',
      selector: row => row.surname,
    },
    {
      name: 'Age',
      selector: row => row.surname,
    },
    {
      name: 'Description',
      selector: row => row.description,
    },
    {
      name: 'Created At',
      selector: row => row.createdAt,
    },
    {
      name: 'View',
      selector: row => {
        return <Button type="button" className="create-button btn btn-primary pull-right" onClick={() => handleSubmit(row.id)}>View</Button>
      },
    },
  ];

  return (
    <div>
      <DataTable
        columns={columns}
        data={state}
      />
      <Link to="/newForm">
        <Button type="button" className="create-button btn btn-primary pull-right">
          Add Form
        </Button>
      </Link>

    </div>
  );
}