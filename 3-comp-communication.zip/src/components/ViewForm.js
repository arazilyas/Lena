import { Container } from 'react-bootstrap';
import Form from 'react-bootstrap/Form';
import { Button } from 'react-bootstrap';
import axios from 'axios';
import { useState } from 'react';
import React, { useEffect } from 'react'
import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

export default function ViewForm() {
  const [Name, setName] = useState('');
  const [Surname, setSurname] = useState('');
  const [Description, setDescription] = useState('');
  const [Age, setAge] = useState('');
  const params = useParams();

  const navigate = useNavigate();
  function handleSubmit(e) {
    navigate("/formList")
  }

  useEffect(() => {
    axios.get("https://localhost:7217/api/User/getByFormId?id=" + params.id)
      .then(res => {
        setName(res.data.name)
        setSurname(res.data.surname)
        setAge(res.data.age)
        setDescription(res.data.description)


      })
      .catch(err => console.log(err));
  }, []);

  return (
    <Container>
      <Form size="sm">
        <Form.Group controlId="exampleForm.ControlInput1">
          <Form.Label>Name</Form.Label>
          <Form.Control
            type="text"
            name="Name"
            value={Name} />
        </Form.Group>

        <Form.Group controlId="exampleForm.ControlInput1">
          <Form.Label>Surname</Form.Label>
          <Form.Control
            type="text"
            name="Surname"
            value={Surname}
          />
        </Form.Group>

        <Form.Group controlId="exampleForm.ControlInput1">
          <Form.Label>Age</Form.Label>
          <Form.Control
            type="number"
            value={Age}
          />
        </Form.Group>

        <Form.Group controlId="exampleForm.ControlInput1">
          <Form.Label>Description</Form.Label>
          <Form.Control
            type="textarea"
            value={Description} />
        </Form.Group>

        <Button type="button" className="create-button btn btn-danger" onClick={handleSubmit}>Back to List</Button>


      </Form>

    </Container>
  );
}