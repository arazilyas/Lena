import FormSave from "./components/FormSave";
import FormList from "./components/FormList";
import { BrowserRouter, Navigate, Route, Routes, Outlet } from "react-router-dom";
import Login from "./components/Login";
import ViewForm from "./components/ViewForm";
import { Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';



function App() {


  function UrlController() {
    const navigate = useNavigate();
    return localStorage.getItem("isLogin") === null ? (
      <Navigate to="/" />
    ) : (
      <div>
        <Button type="button" className="create-button btn btn-danger" onClick={() => {
          localStorage.removeItem("isLogin"); navigate("/")
        }}>Log Out</Button>

        <div id="wrapper">
          <div id="content-wrapper" className="d-flex flex-column">
            <Outlet />
          </div>
        </div>
      </div>
    )

  }

  const unauthorized = <Navigate to={"/"} />
  return (
    <>

      <div className="container-fluid">
        <BrowserRouter>
          <Routes>
            <Route element={<UrlController />}>
              <Route path="/formList" element={<FormList />} />
              <Route path="/newForm" element={<FormSave />} />
              <Route path="/formList/:id" element={<ViewForm />} />
            </Route>
            <Route path="/" element={<Login />} />
          </Routes>
        </BrowserRouter>
      </div>
    </>
  );
}

export default App;
