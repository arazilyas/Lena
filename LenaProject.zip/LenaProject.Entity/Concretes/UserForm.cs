﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LenaProject.Entity.Concretes
{
    public class UserForm
    {
        public int Id { get; set; }
        //public List<Fields> Fields { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Surname { get; set; }
        public string Age { get; set; }
        public string? Description { get; set; }
        public DateTime CreatedAt{ get; set; }
        public int CreatedBy { get; set; }
    }
    //public class Fields
    //{

    //    public int Id { get; set; }
    //    [ForeignKey("UserFormId")]
    //    public int UserFormId { get; set; }
    //    public bool Required { get; set; }
    //    public string Name { get; set; }
    //    public string DataType { get; set; }
    //}
}
