﻿using LenaProject.Dal;
using LenaProject.Repos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LenaProject.Uow
{
    public class Uow : IUow
    {
        LenaContext _db;

        public IUserRep _userRep { get; private set; }

        public void Commit()
        {
            _db.SaveChanges();
        }
        public Uow(LenaContext db, IUserRep usersRep)
        {
            _db = db;
            _userRep = usersRep;
        }
    }
}
