using LenaProject.Dal;
using LenaProject.Entity.Concretes;
using LenaProject.Repos;
using LenaProject.Uow;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddScoped<IUserRep, UserRep<User>>();
builder.Services.AddScoped<IUserFormRep, UserFormRep<UserForm>>();
builder.Services.AddControllers();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddDbContext<LenaContext>(options =>
        options.UseSqlServer(builder.Configuration.GetConnectionString("Baglanti")));
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();



var allowSpecificOrigins = "_allowSpecificOrigins";
builder.Services.AddCors(options =>
{
    options.AddPolicy(name: allowSpecificOrigins,
                      policy =>
                      {
                          policy.WithOrigins(
                               "http://localhost:3000"
                              )
                          .AllowAnyHeader()
                          .AllowAnyMethod()
                          .AllowAnyOrigin()
                          .SetIsOriginAllowedToAllowWildcardSubdomains();
                      });
});
var app = builder.Build();

app.UseCors(x => x
       .AllowAnyOrigin()
       .AllowAnyHeader()
       .AllowAnyMethod()
       .AllowAnyMethod()
       .SetIsOriginAllowedToAllowWildcardSubdomains());
// Configure the HTTP request pipeline.

app.UseCors(allowSpecificOrigins);
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
