﻿using LenaProject.Dto;
using LenaProject.Entity.Concretes;
using LenaProject.Repos;
using Microsoft.AspNetCore.Mvc;

namespace LenaProjectAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserFormController : ControllerBase
    {
        IUserFormRep _userFormRep;
        public UserFormController(IUserFormRep userFormRep)
        {
            _userFormRep = userFormRep;
        }


        [HttpPost("SaveForm")]
        public IActionResult SaveForm(UserFormDTO userFormDTO)
        {
            var userForm = new UserForm();
            userForm.Name = userFormDTO.Name;
            userForm.Surname = userFormDTO.Surname;
            userForm.Age = userFormDTO.Age.ToString();
            userForm.Description = userFormDTO.Description;
            userForm.CreatedAt = DateTime.Now;
            userForm.CreatedBy = 1;

            _userFormRep.Add(userForm);
            _userFormRep.Commit();

            return Ok(true);
        }
        [HttpGet("GetFormList")]
        public IActionResult GetFormList()
        {

            var formList = _userFormRep.List();

            return Ok(formList);
        }
    }
}
