﻿using LenaProject.Dto;
using LenaProject.Entity.Concretes;
using LenaProject.Repos;
using Microsoft.AspNetCore.Mvc;
using System;

namespace LenaProjectAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        IUserRep _userRep;
        IUserFormRep _userFormRep;
        public UserController(IUserRep userRep, IUserFormRep userFormRep)
        {
            _userRep = userRep;
            _userFormRep = userFormRep;
        }


        [HttpPost("register")]
        public IActionResult Register(UserDTO userDTO)
        {
            var user = new User();
            user.UserName = userDTO.UserName;
            user.Password = userDTO.Password;
            _userRep.Add(user);
            _userRep.Commit();
            
            return Ok(true);

        }

        [HttpPost("login")]
        public IActionResult Login(UserDTO userDTO)
        {
            var user = _userRep.List().Where(x => x.UserName == userDTO.UserName).FirstOrDefault();
            if (user == null)
            {
                return Ok(false);
            }
            
            else if (userDTO.UserName == user.UserName && userDTO.Password == user.Password)
            {
                return Ok(true);

            }
                
            else
            {
                return Ok(false);
            }
        }
        [HttpGet("getByFormId")]
        public IActionResult getByFormId(int id)
        {
            var userForm = _userFormRep.Find(id);
            if (userForm == null)
            {
                return NotFound(); 
            }
            return Ok(userForm);
        }
    }
}
