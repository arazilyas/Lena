﻿using LenaProject.Core;
using LenaProject.Entity.Concretes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LenaProject.Repos
{
    //public interface IFieldRep : IBaseRepository<Fields>
    //{
    //    void Commit();
    //}
}
