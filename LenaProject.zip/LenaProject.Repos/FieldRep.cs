﻿using LenaProject.Core;
using LenaProject.Dal;
using LenaProject.Dto;
using LenaProject.Entity.Concretes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LenaProject.Repos
{
    //public class FieldRep<T> : BaseRepository<Fields>, IFieldRep where T : class
    //{
    //    LenaContext _db;
    //    public FieldRep(LenaContext db) : base(db)
    //    {
    //        _db = db;
    //    }

    //    public void Commit()
    //    {
    //        _db.SaveChanges();
    //    }

    //}
}
