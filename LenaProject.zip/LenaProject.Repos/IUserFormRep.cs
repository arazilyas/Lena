﻿using LenaProject.Core;
using LenaProject.Dto;
using LenaProject.Entity.Concretes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LenaProject.Repos
{
    public interface IUserFormRep : IBaseRepository<UserForm>
    {
        UserForm CreateUserForm(UserForm userForm);
        void Commit();
    }
}
