﻿using LenaProject.Core;
using LenaProject.Dal;
using LenaProject.Dto;
using LenaProject.Entity.Concretes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LenaProject.Repos
{
    public class UserRep<T> : BaseRepository<User>, IUserRep where T : class
    {
        LenaContext _db;
        public UserRep(LenaContext db) : base(db)
        {
            _db = db;
        }

        public void Commit()
        {
            _db.SaveChanges();
        }

        //public User CreateUser(User u)
        //{
        //    _db.Set<User>().Add(u);
        //    _db.SaveChanges();
        //    return u;
        //}

        //public bool Login(UserDTO userDTO)
        //{

        //    if (userDTO.UserName == "ilyas" && userDTO.Password == "123456")
        //    {

        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }

        //}
    }
}
