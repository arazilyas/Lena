﻿using LenaProject.Core;
using LenaProject.Dal;
using LenaProject.Dto;
using LenaProject.Entity.Concretes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LenaProject.Repos
{
    public class UserFormRep<T> : BaseRepository<UserForm>, IUserFormRep where T : class
    {
        LenaContext _db;
        public UserFormRep(LenaContext db) : base(db)
        {
            _db = db;
        }

        public void Commit()
        {
            _db.SaveChanges();
        }

        public UserForm CreateUserForm(UserForm userForm)
        {
            _db.Set<UserForm>().Add(userForm);
            _db.SaveChanges();
            return userForm;
        }
    }
}
