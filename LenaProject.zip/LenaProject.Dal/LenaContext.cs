﻿using LenaProject.Entity.Concretes;
using Microsoft.EntityFrameworkCore;


namespace LenaProject.Dal
{
    public class LenaContext : DbContext
    {
        public LenaContext(DbContextOptions<LenaContext>db) : base(db) 
        {

        }
        public DbSet<User> Users { get; set; }
        public DbSet<UserForm> UserForms { get; set; }
    }
}
